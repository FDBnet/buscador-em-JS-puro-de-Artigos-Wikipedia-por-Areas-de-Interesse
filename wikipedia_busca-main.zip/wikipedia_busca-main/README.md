# wikipedia_busca
Buscador de artigos na Wikipédia com base em temas de interesse do usuário



# Imagina o tanto de coisa que da pra trazer da Wikipédia pra um projeto tipo de LLM (vulgo IA generativa) ou outro afim.

Então, por enquanto, eu estou fazendo uns scripts com JS vanilla (puro) e subindo aqui.
